package com.example.quartz.dynamic.job.service;

import java.util.Date;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.mail.SimpleMailMessage;
import org.springframework.mail.javamail.JavaMailSender;
import org.springframework.stereotype.Service;

import com.example.quartz.dynamic.job.jpa.BatchJobRepository;
import com.example.quartz.dynamic.job.model.BatchJob;

/**
 * Created by Ice on 11/4/2016.
 */
@Service
public class SomeService {

    private static final Logger log = LoggerFactory.getLogger(SomeService.class);
    
    @Autowired
	private JavaMailSender javaMailSender;
    
    @Autowired
    private BatchJobRepository batchJobRepository;

    public void writeDataToLog(String dataToWrite) {
        log.info("The data is : " + dataToWrite);
        this.sendEmail();
        log.info("Email Sent successfully");
        log.info("CALLING BATCH JOB TABLE:::");
        this.getDataBaseValues();
        log.info("END OF DB CALL");
        
    }
    
    void sendEmail() {
    	SimpleMailMessage msg = new SimpleMailMessage();
    	msg.setTo("springemail1@mailinator.com");
    	msg.setSubject("ADDING DB FUNCTIONALITY AS WELL");
    	msg.setText("Hello World \n Spring Boot Email");
    	javaMailSender.send(msg);
    }
    
    void getDataBaseValues() {
    	 System.out.println("\nfindById(1L)::::VALUES FROM THE BATCHJOB TABLE::::");
    	 BatchJob newRow = batchJobRepository.findById(1l);
    	 System.out.println("VALUE PULLED FROM DB:: ID"+newRow.getId()+" BATCHJOBNAME::"+newRow.getName()+" DATE::"+newRow.getDate());
    	 
    	 newRow = new BatchJob("ThirdJob", new Date());
    	 //Inserting the data into the table
    	 batchJobRepository.save(newRow);
    	 
    	 //getting new inserted value from the table
    	 newRow = batchJobRepository.findById(2l);
    	 System.out.println("VALUE PULLED FROM DB:: ID --"+newRow.getId()+"-- BATCHJOBNAME::"+newRow.getName()+" DATE::"+newRow.getDate());
    	 
    	
    	 
    	 
    	 
    }
    
    
}
