package com.example.quartz.dynamic.job.model;

import java.util.Date;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;

@Entity
public class BatchJob {
	
	@Id
    @GeneratedValue(strategy = GenerationType.AUTO)
    private Long id;
    private String name;
    private Date date;
	
    public BatchJob(String name, Date date) {
		this.name = name;
		this.date = date;
	}
	public BatchJob() {
		
	}
	public synchronized Long getId() {
		return id;
	}
	public synchronized void setId(Long id) {
		this.id = id;
	}
	public synchronized String getName() {
		return name;
	}
	public synchronized void setName(String name) {
		this.name = name;
	}
	public synchronized Date getDate() {
		return date;
	}
	public synchronized void setDate(Date date) {
		this.date = date;
	}
}
